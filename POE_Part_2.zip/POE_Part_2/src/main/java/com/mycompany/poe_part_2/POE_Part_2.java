package com.mycompany.poe_part_2;

import javax.swing.*;
import java.util.*;
import java.io.FileWriter;
import java.io.IOException;

public class POE_Part_2 {

    static String registeredUsername;
    static String registeredPassword;
    static String registeredPhone;
    static int totalMessagesSent = 0;
    static int messageNumber = 0;

    public static void main(String[] args) {

        // Display welcome message
        JOptionPane.showMessageDialog(null, "Welcome To QuickChat.");

        // Register user
        registerUser();

        // Login check
        if (loginUser()) {
            JOptionPane.showMessageDialog(null,
                    "Login successful. Redirecting to QuickChat...");

            runMessageSystem();

        } else {
            JOptionPane.showMessageDialog(null,
                    "Login failed. Exiting app.");
        }
    }

    // User registration
    public static void registerUser() {

        boolean valid = false;

        while (!valid) {

            // Username validation
            registeredUsername = JOptionPane.showInputDialog(
                    "Create a username (must contain _ and max 5 characters):");

            if (!(registeredUsername.contains("_")
                    && registeredUsername.length() <= 5)) {

                JOptionPane.showMessageDialog(null,
                        "Invalid username.");
                continue;
            }

            // Password validation
            registeredPassword = JOptionPane.showInputDialog(
                    "Create password (8+ chars, 1 capital, 1 number, 1 special character)");

            if (!registeredPassword.matches(
                    "^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$")) {

                JOptionPane.showMessageDialog(null,
                        "Invalid password.");
                continue;
            }

            // Phone validation
            registeredPhone = JOptionPane.showInputDialog(
                    "Enter Phone Number (+27XXXXXXXXX):");

            if (!registeredPhone.matches("^\\+27[6-8]\\d{8}$")) {

                JOptionPane.showMessageDialog(null,
                        "Invalid phone number.");
                continue;
            }

            JOptionPane.showMessageDialog(null,
                    "Registration successful!");

            valid = true;
        }
    }

    // Login method
    public static boolean loginUser() {

        String user = JOptionPane.showInputDialog(
                "Login - Enter your username:");

        String pass = JOptionPane.showInputDialog(
                "Enter your password:");

        return user.equals(registeredUsername)
                && pass.equals(registeredPassword);
    }

    // Main menu
    public static void runMessageSystem() {

        boolean keepRunning = true;

        while (keepRunning) {

            String[] options = {
                    "Send Message",
                    "Coming Soon",
                    "Quit"
            };

            int choice = JOptionPane.showOptionDialog(
                    null,
                    "Choose an Option:",
                    "Main Menu",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]);

            switch (choice) {

                case 0 -> sendMessage();

                case 1 -> JOptionPane.showMessageDialog(
                        null,
                        "Coming Soon.");

                case 2 -> {
                    keepRunning = false;

                    JOptionPane.showMessageDialog(
                            null,
                            "Goodbye!");
                }
            }
        }
    }

    // Send messages
    public static void sendMessage() {

        int count = Integer.parseInt(
                JOptionPane.showInputDialog(
                        "How many messages would you like to send?"));

        for (int i = 0; i < count; i++) {

            messageNumber++;

            String messageID = generateMessageID();

            // Recipient validation
            String recipient = JOptionPane.showInputDialog(
                    "Enter recipient number (+27XXXXXXXXX):");

            if (!recipient.matches("^\\+27\\d{9}$")) {

                JOptionPane.showMessageDialog(null,
                        "Invalid number format.");

                i--;
                continue;
            }

            // Message input
            String message = JOptionPane.showInputDialog(
                    "Enter message (max 250 characters):");

            if (message.length() > 250) {

                JOptionPane.showMessageDialog(
                        null,
                        "Message too long by "
                                + (message.length() - 250)
                                + " characters.");

                i--;
                continue;
            }

            // Generate hash
            String hash = generateMessageHash(
                    messageID,
                    messageNumber,
                    message);

            // User actions
            String[] actions = {
                    "Send",
                    "Disregard",
                    "Store"
            };

            int action = JOptionPane.showOptionDialog(
                    null,
                    "What do you want to do?",
                    "Message Options",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    actions,
                    actions[0]);

            switch (action) {

                case 0 -> {
                    totalMessagesSent++;

                    displayMessageDetails(
                            messageID,
                            hash,
                            recipient,
                            message);
                }

                case 1 -> JOptionPane.showMessageDialog(
                        null,
                        "Message disregarded.");

                case 2 -> {
                    writeMessageToJSON(
                            messageID,
                            hash,
                            recipient,
                            message);

                    JOptionPane.showMessageDialog(
                            null,
                            "Message stored.");
                }
            }
        }

        JOptionPane.showMessageDialog(
                null,
                "Total messages sent: " + totalMessagesSent);
    }

    // Generate random message ID
    public static String generateMessageID() {

        return String.format(
                "%010d",
                new Random().nextInt(1_000_000_000));
    }

    // Generate message hash
    public static String generateMessageHash(
            String id,
            int num,
            String msg) {

        String[] words = msg.trim().split(" ");

        String first = words[0];
        String last = words[words.length - 1];

        return (id.substring(0, 2)
                + ":"
                + num
                + ":"
                + first
                + last).toUpperCase();
    }

    // Display sent message details
    public static void displayMessageDetails(
            String id,
            String hash,
            String recipient,
            String message) {

        JOptionPane.showMessageDialog(
                null,
                "Message ID: " + id
                        + "\nHash: " + hash
                        + "\nRecipient: " + recipient
                        + "\nMessage: " + message);
    }

    // Store message in JSON file
    public static void writeMessageToJSON(
            String messageID,
            String hash,
            String recipient,
            String message) {

        StringBuilder jsonEntry = new StringBuilder();

        jsonEntry.append("{\n");
        jsonEntry.append(" \"MessageID\": \"")
                .append(messageID)
                .append("\",\n");

        jsonEntry.append(" \"MessageHash\": \"")
                .append(hash)
                .append("\",\n");

        jsonEntry.append(" \"Recipient\": \"")
                .append(recipient)
                .append("\",\n");

        jsonEntry.append(" \"Message\": \"")
                .append(message.replace("\"", "\\\\\""))
                .append("\"\n");

        jsonEntry.append("}\n");

        try (FileWriter file = new FileWriter("Jsonnew.json", true)) {

            file.write(jsonEntry.toString());

        } catch (IOException e) {

            JOptionPane.showMessageDialog(
                    null,
                    "Error writing file: " + e.getMessage());
        }
    }
}

